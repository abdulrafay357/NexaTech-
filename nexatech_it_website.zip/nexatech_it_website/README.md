# NexaTech Solutions website

A responsive demo website for a fictional IT company, built with plain HTML, CSS and JavaScript.

## Run it
1. Extract the ZIP file.
2. Open `index.html` in Chrome, Edge, or Firefox.

You can also open the folder in VS Code and use the Live Server extension.

## Customize
- Change the company name, text, phone and email in `index.html`.
- Change colors and layout in `style.css`.
- Update menu and demo form behavior in `script.js`.

## Important
The contact form currently shows a browser confirmation only. To receive real messages, connect it to a backend or an email form service.
